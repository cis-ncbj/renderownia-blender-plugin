import bpy
import addon_utils
import json
from . import config
import requests
import os


class OBJECT_OT_read_scene_settings(bpy.types.Operator):
    bl_idname = 'object.read_scene_settings'
    bl_label = 'Save all data for rendering'
    bl_options = {"REGISTER", "UNDO"}

    def __init__(self):
        self.scene_name = None
        self.cycles_settings = None
        self.workbench_settings = None
        self.eevee_settings = None
        self.output_settings = None
        self.add_ons = None
        self.images = None
        self.result_filename = 'scene_settings.txt'

    def execute(self, context):
        self.scene_name = context.scene.name
        self.read_output(self.scene_name)
        self.read_materials(self.scene_name)
        self.read_add_ons(self.scene_name)
        self.read_eevee(self.scene_name)
        self.read_cycles(self.scene_name)
        self.read_workbench(self.scene_name)
        self.save_as_json()
        self.post_data(self.prepare_payload('test_job', (0, 1), False, self.prepare_tiles_info()))

        return {"FINISHED"}


    # operator może być wywoływany w małym pop-upie

    @classmethod
    def poll(cls, context):
        return context.active_object is not None


    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)


    def read_cycles(self, scene_name):
        color_management = {}

        color_management['display_device'] = bpy.data.scenes[scene_name].display_settings.display_device
        color_management['view_transform'] = bpy.data.scenes[scene_name].view_settings.view_transform
        color_management['look'] = bpy.data.scenes[scene_name].view_settings.look
        color_management['exposure'] = bpy.data.scenes[scene_name].view_settings.exposure
        color_management['gamma'] = bpy.data.scenes[scene_name].view_settings.gamma
        color_management['sequencer'] = bpy.data.scenes[scene_name].sequencer_colorspace_settings.name

        sampling = {}

        integrator = bpy.data.scenes[scene_name].cycles.progressive
        sampling['integrator'] = integrator

        sampling['render'] = bpy.data.scenes[scene_name].cycles.samples
        sampling['viewport'] = bpy.data.scenes[scene_name].cycles.preview_samples

        if integrator == 'BRANCHED_PATH':
            sampling['sub_samples'] = {}
            sampling['sub_samples']['diffuse'] = bpy.data.scenes[scene_name].cycles.diffuse_samples
            sampling['sub_samples']['glossy'] = bpy.data.scenes[scene_name].cycles.glossy_samples
            sampling['sub_samples']['transmission'] = bpy.data.scenes[scene_name].cycles.transmission_samples
            sampling['sub_samples']['ao'] = bpy.data.scenes[scene_name].cycles.ao_samples
            sampling['sub_samples']['mesh_light'] = bpy.data.scenes[scene_name].cycles.mesh_light_samples
            sampling['sub_samples']['subsurface'] = bpy.data.scenes[scene_name].cycles.subsurface_samples
            sampling['sub_samples']['volume'] = bpy.data.scenes[scene_name].cycles.volume_samples

        light_paths = {}
        max_bounces = {}
        clamping = {}
        caustics = {}

        max_bounces['total'] = bpy.data.scenes[scene_name].cycles.max_bounces
        max_bounces['diffuse'] = bpy.data.scenes[scene_name].cycles.diffuse_bounces
        max_bounces['glossy'] = bpy.data.scenes[scene_name].cycles.glossy_bounces
        max_bounces['transparency'] = bpy.data.scenes[scene_name].cycles.transparent_max_bounces
        max_bounces['transmission'] = bpy.data.scenes[scene_name].cycles.transmission_bounces
        max_bounces['volume'] = bpy.data.scenes[scene_name].cycles.volume_bounces

        light_paths['max_bounces'] = max_bounces

        clamping['direct_light'] = bpy.data.scenes[scene_name].cycles.sample_clamp_direct
        clamping['indirect_light'] = bpy.data.scenes[scene_name].cycles.sample_clamp_indirect

        light_paths['clampling'] = clamping

        caustics['filter_glossy'] = bpy.data.scenes[scene_name].cycles.blur_glossy
        caustics['reflective_caustics'] = bpy.data.scenes[scene_name].cycles.caustics_reflective
        caustics['refractive_caustics'] = bpy.data.scenes[scene_name].cycles.caustics_refractive

        light_paths['caustics'] = caustics

        self.cycles_settings = {'color_management': color_management, 'sampling': sampling, 'light_paths': light_paths}

    def read_workbench(self, scene_name):
        lightning = {'light': bpy.data.scenes[scene_name].display.shading.light}

        if lightning['light'] in ['STUDIO', 'MATCAP']:
            lightning['studio_light'] = bpy.data.scenes[scene_name].display.shading.studio_light

        color = {'type': bpy.data.scenes[scene_name].display.shading.color_type}

        if color['type'] == 'SINGLE':
            color['red'] = bpy.data.scenes[scene_name].display.shading.single_color[0]
            color['green'] = bpy.data.scenes[scene_name].display.shading.single_color[1]
            color['blue'] = bpy.data.scenes[scene_name].display.shading.single_color[2]

        self.workbench_settings = {'lightning': lightning, 'color': color}

    def read_eevee(self, scene_name):
        sampling = {}

        sampling['render'] = bpy.data.scenes[scene_name].eevee.taa_render_samples
        sampling['viewport'] = bpy.data.scenes[scene_name].eevee.taa_samples

        self.eevee_settings = {'sampling': sampling}

    def read_output(self, scene_name):
        dimensions = {"resolution": {}, "aspect": {}, "border": None, "crop": None, "frame": {}, "time_remapping": {}}

        dimensions["resolution"]["x"] = bpy.data.scenes[scene_name].render.resolution_x
        dimensions["resolution"]["y"] = bpy.data.scenes[scene_name].render.resolution_y
        dimensions["resolution"]["percentage"] = bpy.data.scenes[scene_name].render.resolution_percentage

        dimensions["aspect"]["x"] = bpy.data.scenes[scene_name].render.pixel_aspect_x
        dimensions["aspect"]["y"] = bpy.data.scenes[scene_name].render.pixel_aspect_y

        dimensions["border"] = bpy.data.scenes[scene_name].render.use_border

        if dimensions["border"]:
            dimensions["crop"] = bpy.data.scenes[scene_name].render.use_crop_to_border

        dimensions["frame"]["start"] = bpy.data.scenes[scene_name].frame_start
        dimensions["frame"]["end"] = bpy.data.scenes[scene_name].frame_end
        dimensions["frame"]["step"] = bpy.data.scenes[scene_name].frame_step
        dimensions["frame"]["rate"] = bpy.data.scenes[scene_name].render.fps

        dimensions["time_remapping"]["old"] = bpy.data.scenes[scene_name].render.frame_map_old
        dimensions["time_remapping"]["new"] = bpy.data.scenes[scene_name].render.frame_map_new

        output = {"views": {}}
        stereoscopy = {"use": None}

        output["path"] = bpy.data.scenes[scene_name].render.filepath

        output["overwirte"] = bpy.data.scenes[scene_name].render.use_overwrite
        output["placeholders"] = bpy.data.scenes[scene_name].render.use_placeholder
        output["file_extensions"] = bpy.data.scenes[scene_name].render.use_file_extension
        output["cache_result"] = bpy.data.scenes[scene_name].render.use_render_cache

        file_format = bpy.data.scenes[scene_name].render.image_settings.file_format
        output["file_format"] = file_format

        if file_format in ['PNG', 'TIFF']:
            output["color"] = bpy.data.scenes[scene_name].render.image_settings.color_mode
            output["color_depth"] = bpy.data.scenes[scene_name].render.image_settings.color_depth
            output["compression"] = bpy.data.scenes[scene_name].render.image_settings.compression

        if file_format == 'JPEG':
            output["color"] = bpy.data.scenes[scene_name].render.image_settings.color_mode
            output["compression"] = bpy.data.scenes[scene_name].render.image_settings.quality

        if file_format == 'BMP':
            output["color"] = bpy.data.scenes[scene_name].render.image_settings.color_mode

        stereoscopy["use"] = bpy.data.scenes[scene_name].render.use_multiview

        if stereoscopy["use"]:
            output["views"]["views_format"] = bpy.data.scenes[scene_name].render.image_settings.views_format

            if output["views"]["views_format"] == 'STEREO_3D':
                pass

            stereoscopy["setup_stereo_mode"] = bpy.data.scenes[scene_name].render.views_format

            for i in range(len(bpy.data.scenes[scene_name].render.views)):
                view_name = bpy.data.scenes["Scene"].render.views[i].name
                is_view_used = bpy.data.scenes["Scene"].render.views[i].use
                suffix = None

                if stereoscopy["setup_stereo_mode"] == 'MULTI-VIEW':
                    suffix = bpy.data.scenes[scene_name].render.views["right"].camera_suffix
                else:
                    suffix = bpy.data.scenes[scene_name].render.views["right"].file_suffix

                stereoscopy[view_name] = (is_view_used, suffix)

        metadata = {}

        metadata["date"] = bpy.data.scenes[scene_name].render.use_stamp_date
        metadata["time"] = bpy.data.scenes[scene_name].render.use_stamp_time
        metadata["render_time"] = bpy.data.scenes[scene_name].render.use_stamp_render_time
        metadata["frame"] = bpy.data.scenes[scene_name].render.use_stamp_frame
        metadata["frame_range"] = bpy.data.scenes[scene_name].render.use_stamp_frame_range
        metadata["memory"] = bpy.data.scenes[scene_name].render.use_stamp_memory
        metadata["hostname"] = bpy.data.scenes[scene_name].render.use_stamp_hostname
        metadata["camera"] = bpy.data.scenes[scene_name].render.use_stamp_camera
        metadata["lens"] = bpy.data.scenes[scene_name].render.use_stamp_lens
        metadata["scene"] = bpy.data.scenes[scene_name].render.use_stamp_scene
        metadata["marker"] = bpy.data.scenes[scene_name].render.use_stamp_marker
        metadata["filename"] = bpy.data.scenes[scene_name].render.use_stamp_filename
        metadata["strip_name"] = bpy.data.scenes[scene_name].render.use_stamp_sequencer_strip
        metadata["use_strip_metadata"] = bpy.data.scenes[scene_name].render.use_stamp_strip_meta

        if metadata["use_strip_metadata"]:
            metadata["note_text"] = bpy.data.scenes[scene_name].render.stamp_note_text

        metadata["burn_into_image"] = bpy.data.scenes[scene_name].render.use_stamp

        if metadata["burn_into_image"]:
            metadata["font_size"] = bpy.data.scenes[scene_name].render.stamp_font_size
            metadata["draw_labels"] = bpy.data.scenes[scene_name].render.use_stamp_labels
            metadata["text_color"] = bpy.data.scenes[scene_name].render.stamp_foreground
            metadata["background"] = bpy.data.scenes[scene_name].render.stamp_background

        postprocessing = {}

        postprocessing["compositing"] = bpy.data.scenes[scene_name].render.use_compositing
        postprocessing["sequencer"] = bpy.data.scenes[scene_name].render.use_sequencer
        postprocessing["dither"] = bpy.data.scenes[scene_name].render.dither_intensity

        self.output_settings = {"dimensions": dimensions, "output": output, "metadata": metadata,
                                "stereoscopy": stereoscopy,
                                "postprocessing": postprocessing, "renderer": bpy.data.scenes[scene_name].render.engine}

    def read_materials(self, scene_name):
        self.images = []
        for image in bpy.data.images:
            # if the image is used anywhere
            if image.users:
                # if not packed, get path
                if image.packed_file == None:
                    image_data = dict(
                        name = image.name,
                        full_path = bpy.path.abspath(image.filepath))
                    self.images.append(image_data)


    def read_add_ons(self, scene_name):
        for mod in addon_utils.modules():
            print(mod.bl_info.get('version'))
            print(mod.bl_info.get('name'))

    def save_as_json(self):
        data = {
            "cycles": self.cycles_settings,
            "workbench": self.workbench_settings,
            "eevee": self.eevee_settings,
            "output": self.output_settings,
            "materials": self.images,
            "add-ons": self.add_ons
        }
        with open(self.result_filename, 'w') as outfile:
            json.dump(data, outfile)

    # parametry czytane z gui wtyczki czy z paneli render/output?

    def prepare_payload(self, job_name, frames, anim_prepass=False, tiles_info=None,
        output_format="jpeg", priority=0, sanity_check=False):

        data = dict(
            textures = self.images,
            scene = self.prepare_scene_file_data(),
            name = job_name,
            frames = dict(
                start = frames[0],
                end = frames[1]
            ),
            anim_prepass = anim_prepass,
            output_format = output_format,
            priority = priority,
            sanity_check = sanity_check
        )
        if tiles_info:
            data.update(self.prepare_tiles_info())
        else:
            data['tile_job']=False
        return data

    
    def post_data(self, payload):
        print(json.dumps(payload))
        headers = {'content-type': 'application/json'}
        r = requests.post(config.server, data=json.dumps(payload), headers=headers)
        print(r.text)


    def prepare_scene_file_data(self):
        scene_file_data = {                 # temporary
            "name": "wall.blend",
            "full_path": "/home/gaboss/blends/wall/wall.blend"
        } 

        return scene_file_data

    def prepare_tiles_info(self):
        tile_info = {                        # temporary
            "tile_job": True, 
            "tiles": {
                "padding": 10, 
                "y": 2, 
                "x": 2
            },
            "tile_padding": 10
        }

        return tile_info
