import bpy
# from . read_scene_settings import OBJECT_OT_read_scene_settings

from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       EnumProperty,
                       )

my_bool : BoolProperty(
    name="Enable or Disable",
    description="A bool property",
    default = False
    )

my_int : IntProperty(
    name = "Set a value",
    description="A integer property",
    default = 23,
    min = 10,
    max = 100
    )

class TOPBAR_MT_custom_sub_menu(bpy.types.Menu):
    bl_label = "Render"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_DEFAULT'
        layout.operator("object.read_scene_settings")


class TOPBAR_MT_custom_menu(bpy.types.Menu):
    bl_label = "CIS Render"

    def draw(self, context):
        layout = self.layout
        layout.menu("TOPBAR_MT_custom_sub_menu")

    def menu_draw(self, context):
        self.layout.menu("TOPBAR_MT_custom_menu")


class EXAMPLE_PT_panel(bpy.types.Panel):
    bl_label = "My own addon"
    bl_category = "Name of your tab"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def draw(self, context):
        layout = self.layout

        layout.label(text="This is a label")

class EXAMPLE_PT_panel2(bpy.types.Panel):
    bl_label = "My own addon2"
    bl_category = "Name of your tab2"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def draw(self, context):
        layout = self.layout

        layout.label(text="This is a label2")