# protocol = 'http'
# server = 'https://httpbin.org/post'
server = 'http://localhost:5000/job'