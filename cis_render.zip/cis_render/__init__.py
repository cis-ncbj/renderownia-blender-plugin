bl_info = {
    'blender': (2, 80, 75),
    'name': 'CIS Render Add-On',
    'category': 'Object',
    'version': (0, 0, 1)
}

import bpy
import importlib

from . import read_scene_settings
from . import ui
from . import config

from . read_scene_settings import ( OBJECT_OT_read_scene_settings  )

from . ui import ( TOPBAR_MT_custom_sub_menu,
                   TOPBAR_MT_custom_menu,
                   EXAMPLE_PT_panel,
                   EXAMPLE_PT_panel2
                 )

classes = (
    OBJECT_OT_read_scene_settings,
    TOPBAR_MT_custom_sub_menu,
    TOPBAR_MT_custom_menu,
    EXAMPLE_PT_panel,
    EXAMPLE_PT_panel2
)


def register():

    importlib.reload(read_scene_settings)
    importlib.reload(ui)
    importlib.reload(config)

    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_editor_menus.append(TOPBAR_MT_custom_menu.menu_draw)


def unregister():
    bpy.types.TOPBAR_MT_editor_menus.remove(TOPBAR_MT_custom_menu.menu_draw)
    for cls in classes:
        bpy.utils.unregister_class(cls)
        
if __name__ == "__main__":
    register()